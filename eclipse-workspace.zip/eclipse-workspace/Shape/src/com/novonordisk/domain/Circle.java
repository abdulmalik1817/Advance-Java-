package com.novonordisk.domain;

public class Circle extends Shape {
@Override
public void draw() {
	// TODO Auto-generated method stub
 System.out.println("Drawing Circle");	
}
}
