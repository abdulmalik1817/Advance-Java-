package com.novonordisk.main;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class WriteFileMain {
public static void main(String[] args) {
	String path = "c:/FileIO/write.odt";
	
	File file = new File(path);
	
	try {
		FileWriter fileWriter = new FileWriter(file, true);
		fileWriter.write("This is again new sample data");
		fileWriter.close();
		System.out.println("Please check if file is created");
	} catch (IOException e) {
		System.out.println("Failed to create a file OR File doesnt exist");
	}
	
}
}
