package com.novonordisk.main;

import com.novonordisk.domain.MyClass;

public class MyClassMain {
public static void main(String[] args) {
	MyClass myclass =  new MyClass();
	System.out.println(myclass.getData());
	
	int [] num = new int[3];
	num [0]= 17;
	num [1]= 18;
	num [2]= 03;
	
	myclass.setData(num);
	//System.out.println(myclass.getData());
	
	for(int i : num) {
		System.out.println(i);
	}
	System.out.println("++++++++++++++++++++++++");
	System.out.println("Values from class"); // [23,22,21]
	for (int i : myclass.getData()){
	System.out.println(i);
	}
	
	System.out.println("+++++++++++++++++++++++++++++++++");
	System.out.println("Change in array of main");
	num[1]= 100;
	System.out.println("++++++++++++++++++++++++++++++++++++++++");
	System.out.println("Values from class"); // [23,100,21]
	for(int i : myclass.getData()) {
		System.out.println(i);
	}
	System.out.println("Values from main"); // 23,100,21
	for(int i:num) {
		System.out.println(i);
	}
	
}
}
