package com.novonordisk.domain;

public class MyClass {
private int[] data;

public int[] getData() {
	return data;
}

public void setData(int[] data) {
	this.data = data;
}

}
