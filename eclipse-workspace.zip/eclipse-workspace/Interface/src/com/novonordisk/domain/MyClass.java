package com.novonordisk.domain;

public class MyClass implements Greet{
@Override
public void doGreet() {
	// TODO Auto-generated method stub
	
}
}
