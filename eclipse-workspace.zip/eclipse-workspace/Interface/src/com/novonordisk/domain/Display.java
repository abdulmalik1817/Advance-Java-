package com.novonordisk.domain;

public interface Display {
//	 public abstract void print();
void print();
}
