package com.novonordisk.domain;

public class User implements Greet, Display {
@Override
public void doGreet() {
	// TODO Auto-generated method stub
	
}

@Override
public void print() {
	// TODO Auto-generated method stub
	
}
}
