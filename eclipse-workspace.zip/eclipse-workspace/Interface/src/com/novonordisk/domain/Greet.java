package com.novonordisk.domain;

public interface Greet {
//public abstract void greet();
void doGreet();
}
