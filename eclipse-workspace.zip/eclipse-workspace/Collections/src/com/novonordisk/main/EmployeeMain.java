package com.novonordisk.main;

import java.util.HashSet;

import com.novonordisk.domain.Employee;

public class EmployeeMain {
public static void main(String[] args) {
	Employee emp1 = new Employee(201, "Rahul", 10500);
	Employee emp2 = new Employee(202, "abhi", 20500);
	Employee emp3 = new Employee(203, "Flin", 30500);
	
	HashSet<Employee> empSet = new HashSet<Employee>();
	
	EmployeeSet.
	
	System.out.println(empSet);
	for(Employee i : empSet) {
		System.out.println(i.getEmpid()+" " + i.getEmpname()+ " "+ i.getEmpsalary());
	}
}
}
