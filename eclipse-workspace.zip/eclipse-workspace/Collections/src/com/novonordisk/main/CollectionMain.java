package com.novonordisk.main;

import java.util.ArrayList;
import java.util.HashSet;

public class CollectionMain {

	public static void main(String[] args) {
		System.out.println("1. ArrayList");
		
		ArrayList<String> names = new ArrayList<String>();
		System.out.println(names.size());
		names.add("Rahul");
		names.add("Ben");
		names.add("flin");
		System.err.println(names.size());
		System.out.println(names);
		
		
	System.out.println("2. HashSet");
	HashSet<String> nameSet = new HashSet<String>();
	System.out.println(nameSet.size());
	nameSet.add("Remo");
	nameSet.add("Sandy");
	nameSet.add("Anrew");
	nameSet.add("Ben");
	nameSet.add(null);
	System.out.println(nameSet.size());
	System.out.println(names);
	
	System.out.println("2. Treeset");
	TreeSet<String> nameSet = new HashSet<String>();
	System.out.println(nameSet.size());
	nameSet.add("Remo");
	nameSet.add("Sandy");
	nameSet.add("Anrew");
	nameSet.add("Ben");
	nameSet.add(null);
	System.out.println(nameSet.size());
	System.out.println(names);
		
	}
}
