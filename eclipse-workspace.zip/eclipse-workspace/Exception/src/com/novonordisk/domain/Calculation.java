package com.novonordisk.domain;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Calculation {
private int num1;
private int num2;
private int result;

public void accept() {
	try {
	
	System.out.println("accept() start");
	Scanner scanner = new Scanner (System.in);
	System.out.println("Enter num1");
	num1 = scanner.nextInt();
	System.out.println("Enter num2");
	num2 = scanner.nextInt();		
	System.out.println("accept() end");
	}
	catch (InputMismatchException i) {
		System.out.println("Invalid input from user");
		System.out.println("Please enter valid number");
	}

}
public void calculateresult() {
	System.out.println("calculateresult() start");
	result = num1 + num2;
	System.out.println("calculateresult() end");
}
public void display() {
	System.out.println("display() start");
	System.out.println("result = " + result);
	System.out.println("() end");
}
}