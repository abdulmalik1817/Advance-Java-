package com.novonordisk.domain;

public class CalculationMain {
public static void main(String[] args) {
	System.out.println("main start");
	
	Calculation calculation = new Calculation();
	
	calculation.accept();
	calculation.calculateresult();
	calculation.display();
	
	System.out.println("main end");
}
}
