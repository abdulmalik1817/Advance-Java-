package com.novonordisk.main;

import java.util.Scanner;

public class PDF extends DocumentFormat {
@Override
public void downloadDocument() {
	// TODO Auto-generated method stub
	super.downloadDocument();
	System.out.println("Downloading PDF");
}
}
			

