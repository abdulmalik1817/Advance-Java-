package com.novonordisk.main;

import java.util.Scanner;

public class DocumentFormatMain {
public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	
	int choice;
	System.out.println("Choose your format");
	System.out.println("1. PDF");
	System.out.println("2. XLS");
	System.out.println("3. CSV");
	System.out.println("4. Enter the choice");
	choice = scanner.nextInt();
	
	switch (choice) {
	case 1 :
		PDF pdf = new PDF ();
		pdf.downloadDocument();
		break;
	case 2 :
		XLS xls = new XLS ();
		xls.downloadDocument();
		break;
	case 3 :
		CSV csv = new CSV ();
		csv.downloadDocument();
		break;
		
	default:
		System.out.println("Invalid choice");
		break;
	}
}
}

