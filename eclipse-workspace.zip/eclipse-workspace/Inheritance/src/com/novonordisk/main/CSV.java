package com.novonordisk.main;

public class CSV extends DocumentFormat {
@Override
public void downloadDocument() {
	// TODO Auto-generated method stub
	super.downloadDocument();
	System.out.println("Downloading CSV");
}
}
