package com.novonordisk.main;
 
public class DocumentFormat {
	public void downloadDocument() {
		System.out.println("Downloading Document");
	}
 
}