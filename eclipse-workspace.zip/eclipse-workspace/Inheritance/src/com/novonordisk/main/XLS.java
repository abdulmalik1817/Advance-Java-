package com.novonordisk.main;

public class XLS extends DocumentFormat {
@Override
public void downloadDocument() {
	// TODO Auto-generated method stub
	super.downloadDocument();
	System.out.println("Downloading XLS");
}
}
