package com.novonordisk.main;

import java.util.Scanner;

public class PolymorphismMain {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		DocumentFormat documentFormat = null;
		int choice;
		System.out.println("Choose your format");
		System.out.println("1. PDF");
		System.out.println("2. XLS");
		System.out.println("3. CSV");
		System.out.println("4. Enter the choice");
		choice = scanner.nextInt();
		
		switch (choice) {
		case 1 :
			documentFormat = new PDF();
			break;
			
		case 2 :
			documentFormat = new XLS();
			break;
		case 3 :
			documentFormat = new CSV();
			break;
			
		default:
			System.out.println("Invalid choice");
			break;
		}
		documentFormat.downloadDocument();
	}
	}

