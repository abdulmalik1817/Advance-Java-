package com.novonordisk.main;

import java.util.Scanner;

import com.novonordisk.domain.Account;

public class AccountMainV2 {
	
	
public static void main (String[] args) {
	Scanner scanner = new Scanner(System.in);
	int accountNumber;
	String name;
	double balance;
	int choice;
	boolean result;
	String continuechoice;
	
	System.out.println("Enter account number");
	accountNumber = scanner.nextInt();
	System.out.println("Enter name");
	name = scanner.next();
	System.out.println("Enter balance");
	balance = scanner.nextDouble();
	
	Account account = new Account(accountNumber, name, balance);
	
	do {
		System.out.println("Menu");
		System.out.println("1. Withdraw");
		System.out.println("2. Deposit");
		System.out.println("3. Check balance");
		System.out.println("4. Invalid choice");
		choice = scanner.nextInt();
		
		double amount;
		switch (choice) {
		case 1:
			System.out.println("You have selected withdraw");
			System.out.println("Enter the amount");
			amount = scanner.nextDouble();
			result = account.withdraw(amount);
			if (result == true)
				System.out.println("Withdraw successfull");
			else
				System.out.println("Withdraw failed");
			break;
		case 2:
			System.out.println("You have selected Deposit");
			System.out.println("Enter the amount");
			amount = scanner.nextDouble();
			result = account.deposit(amount);
			if (result == true)
				System.out.println("Deposit successfull");
			else
				System.out.println("Deposit failed");
			break;
		case 3:
			System.out.println("You have selected Check balance");
			System.out.println("Balance = " + account.getBalance());
			break;
		default:
			System.out.println("Invalid choice");
			break;
		}
	
		System.out.println("Do you want to continue? Y || N");
		continuechoice = scanner.next();
	}while (continuechoice.equals("Y"));
		System.out.println("Thank you");
}
}
