package com.novonordisk.main;

import java.util.Scanner;

public class WhileLoopMain {
	public static void main(String[] args) {
//		int i = 0;
//		while(i<10) {
//			System.out.println(i);
//			i = i + 1;
//		}
//			System.out.println("Out of loop");
//		}
	// Accept number from user
		// Print multiplication from table
		int num;
		int i = 5;
		int result;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the number");
		num = scanner.nextInt()
		i = scanner.nextInt();
		while(i<=10){
			result = num*i;
			System.out.println();
		}
		}

	
		
	}
		
		
}

