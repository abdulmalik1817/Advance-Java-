package com.novonordisk.main;

public class ArrayMain {
	public static void main(String[] args) {
		int num[] = new int[7];
		num [0] = 12;
		num [1] = 23;
		num [2] = 45;
		num [3] = 56;
		num [4] = 98;
		num [5] = 39;
		num [6] = 15;
		
		for(int i=0; i<7;i++) {
			System.out.println(num[i]);
	}
	}
}
